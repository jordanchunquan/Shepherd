compliance_check_list: list[dict] = []

def reset_compliance_list():
    global compliance_check_list
    compliance_check_list.clear()